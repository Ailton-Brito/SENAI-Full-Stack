function calculo() {
    
    let nome = prompt('Digite o seu nome');
    let quantidadeDePassageiros = prompt('Digite a quantidade de passageiros:');
    let valorViagem = prompt('Digite o valor da viagem:');

    let resultado = quantidadeDePassageiros * valorViagem;

    let mensagem = "Orçamento <br> Nome do cliente: " + nome + "<br>";
    mensagem += "Valor da viagem: R$ " + resultado + ",00";




    document.querySelector("div").innerHTML = mensagem;
    }