function validar_campos() {
    let nome = document.querySelector("#nome");
    if (nome.value == "") {
        alert("Preencha o nome");
        console.log(nome.value);
        return false;
    }

    let cpf = document.querySelector("#cpf");
    if (cpf.value == "") {
        alert("Preencha o cpf");
        console.log(cpf.value);
        return false;
    }

    return true;
}

function validar_cpf() {
    let cpf = document.querySelector("#cpf").value;

    let regex = /[0-9]{3}[.]?[0-9]{3}[.]?[0-9]{3}[.\-\/]?[0-9]{2}/;

    if (!regex.test(cpf)) {
        alert("Preencha o cpf corretamente");
        return false;
    }
    return true
}



function validar_tudo() {

    event.preventDefault;

    if (validar_campos() && validar_cpf()) {
        document.querySelector("#btn_assinar").disabled = false;
    }

}

let obj_json = `{
    "login": "Usuario",
    "senha": "Abc$123"
}`;


function fazer_login() {
    let usuario = JSON.parse(json);
    let login = document.querySelector('#login').value;
    let senha = document.querySelector('#senha').value;


    if (usuario.login == login && usuario.senha == senha) {
        return true;
    } else {
        alert("Login e Senha não confere com JSON!");

    }

}

setInterval(contar, 1000);
var contador = 1;
function contar() {
    document.querySelector("#tempo").innerHTML = contador;
    contador++;

}

var resultado_plano = 0;
var resultado_premiere = 0;

function calculo() {

    let planos = document.querySelector("input[name='planos']:checked").value;
    let premiere = document.querySelector("input[name='premiere']:checked").value;

    console.log(planos);
    console.log(premiere);


    if (planos == "M") {
        resultado_plano = 85;
    } else if (planos == "Q") {
        resultado_plano = 300 / 4;
    } else {
        resultado_plano = 600 / 12;
    }

    if (premiere == "E") {
        resultado_premiere = 60;
    } else {
        resultado_premiere = 80;
    }

    console.log(resultado_plano);
    console.log(resultado_premiere);

    let resultado = resultado_plano + resultado_premiere;
    console.log(resultado);

    document.querySelector('#total').value = resultado;

}