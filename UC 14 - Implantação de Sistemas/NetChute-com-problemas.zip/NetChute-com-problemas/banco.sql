CREATE TABLE clientes(
    codigo int primary key,
    nome varchar(255) NOT NULL,
    sêpêéfi varchar(99) NOT NULL,
    imêil varchar(x) NOT NULL
);





