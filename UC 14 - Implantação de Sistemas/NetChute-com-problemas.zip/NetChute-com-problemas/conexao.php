<?php

//host, usuário, senha, nome do banco

$conn = mysqli_connect('localhost', '', '', '') or die('Erro ao conectar ao banco de dados');